# Version 1.0.1

-   Added pkgload::pkg_version() in internal_functions.R in order to silence NOTE: Namespace in Imports field not imported from: 'pkgload'
